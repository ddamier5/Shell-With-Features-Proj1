#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include "jobs.h"

void job_table_init(job_table_t *table) {
    memset(table, 0, sizeof(job_table_t));
    table->next_job_num = 1;
    table->count = 0;
    for (int i = 0; i < MAX_JOBS; i++) {
        table->jobs[i].in_use = 0;
    }
}

/* Find the index of the first free (not in_use) slot, or -1 if none. */
static int find_free_slot(job_table_t *table) {
    for (int i = 0; i < MAX_JOBS; i++) {
        if (!table->jobs[i].in_use) {
            return i;
        }
    }
    return -1;
}

int job_add(job_table_t *table, pid_t pid, const char *cmdline) {
    int slot = find_free_slot(table);
    if (slot == -1) {
        /* Should not happen given the "max 10 concurrent jobs" assumption. */
        fprintf(stderr, "shell: job table full, cannot track background job\n");
        return -1;
    }

    job_t *job = &table->jobs[slot];
    job->job_num = table->next_job_num++;
    job->pid = pid;
    job->status = JOB_RUNNING;
    job->in_use = 1;

    strncpy(job->cmdline, cmdline, MAX_CMDLINE_LEN);
    job->cmdline[MAX_CMDLINE_LEN] = '\0';

    table->count++;

    printf("[%d] %d\n", job->job_num, (int)job->pid);

    return job->job_num;
}

void job_check_finished(job_table_t *table) {
    for (int i = 0; i < MAX_JOBS; i++) {
        job_t *job = &table->jobs[i];
        if (!job->in_use || job->status != JOB_RUNNING) {
            continue;
        }

        int status;
        pid_t result = waitpid(job->pid, &status, WNOHANG);

        if (result == job->pid) {
            /* Job finished */
            printf("[%d]+ done %s\n", job->job_num, job->cmdline);
            job->in_use = 0;
            table->count--;
        } else if (result == -1) {
            /* PID no longer valid (e.g. already reaped elsewhere).
             * Treat as finished so we don't leak the slot forever. */
            printf("[%d]+ done %s\n", job->job_num, job->cmdline);
            job->in_use = 0;
            table->count--;
        }
        /* result == 0 means still running; leave it as-is */
    }
}

void job_print_all(const job_table_t *table) {
    if (table->count == 0) {
        printf("No active background processes.\n");
        return;
    }

    for (int i = 0; i < MAX_JOBS; i++) {
        const job_t *job = &table->jobs[i];
        if (job->in_use) {
            printf("[%d]+ %d %s\n", job->job_num, (int)job->pid, job->cmdline);
        }
    }
}

void job_wait_all(job_table_t *table) {
    for (int i = 0; i < MAX_JOBS; i++) {
        job_t *job = &table->jobs[i];
        if (!job->in_use) {
            continue;
        }

        int status;
        waitpid(job->pid, &status, 0); /* blocking */

        printf("[%d]+ done %s\n", job->job_num, job->cmdline);
        job->in_use = 0;
        table->count--;
    }
}
