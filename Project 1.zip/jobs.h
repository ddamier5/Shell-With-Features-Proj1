#ifndef JOBS_H
#define JOBS_H

#include <sys/types.h>

#define MAX_JOBS 10
#define MAX_CMDLINE_LEN 200   /* spec guarantees commands are < 200 chars */

typedef enum {
    JOB_RUNNING,
    JOB_DONE
} job_status_t;

typedef struct {
    int job_num;                        /* 1-indexed, assigned once, never reused        */
    pid_t pid;                          /* PID to report (last process in a pipeline)     */
    char cmdline[MAX_CMDLINE_LEN + 1];  /* original command line, for completion message */
    job_status_t status;
    int in_use;                         /* 1 if this slot holds a live job, 0 if free     */
} job_t;

typedef struct {
    job_t jobs[MAX_JOBS];
    int next_job_num;   /* starts at 1, always increments, never resets */
    int count;          /* number of currently running jobs             */
} job_table_t;

/* Initialize an empty job table. Call once at shell startup. */
void job_table_init(job_table_t *table);

/*
 * Register a new background job.
 * - pid: PID of the process to track (for pipelines, the LAST command's pid)
 * - cmdline: the original, unmodified command line text
 *
 * Prints "[N] PID" to stdout on success, per spec.
 * Returns the assigned job number, or -1 if the table is full
 * (should not happen given the "max 10 concurrent" assumption, but
 * guard against it anyway).
 */
int job_add(job_table_t *table, pid_t pid, const char *cmdline);

/*
 * Poll all running jobs with waitpid(..., WNOHANG) and reap any that
 * have finished. For each newly finished job, prints:
 *     "[N]+ done <cmdline>"
 * and frees its slot. Call this once per main-loop iteration,
 * before printing the prompt.
 */
void job_check_finished(job_table_t *table);

/*
 * Print all currently running jobs in the format:
 *     "[N]+ PID cmdline"
 * If there are no active jobs, prints a message saying so.
 * Used by the 'jobs' builtin.
 */
void job_print_all(const job_table_t *table);

/*
 * Block until every remaining job in the table has finished
 * (blocking waitpid, no WNOHANG). Used by the 'exit' builtin,
 * which must wait for background jobs before terminating the shell.
 */
void job_wait_all(job_table_t *table);

#endif /* JOBS_H */
